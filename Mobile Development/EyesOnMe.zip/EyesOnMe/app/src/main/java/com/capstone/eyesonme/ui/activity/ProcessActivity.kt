package com.capstone.eyesonme.ui.activity

import android.content.Intent
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.capstone.eyesonme.R
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.asRequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import java.io.File
import java.util.concurrent.TimeUnit

class ProcessActivity : AppCompatActivity() {
    private lateinit var previewImageView: ImageView
    private lateinit var retakeImageButton: Button
    private lateinit var uploadButton: Button
    private lateinit var progressIndicator: LinearProgressIndicator
    private val firestore = FirebaseFirestore.getInstance()

    private var currentPhotoPath: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_process)

        previewImageView = findViewById(R.id.previewImageView)
        retakeImageButton = findViewById(R.id.retakeImageButton)
        uploadButton = findViewById(R.id.uploadButton)
        progressIndicator = findViewById(R.id.progressIndicator)

        // Dapatkan path gambar dari intent
        currentPhotoPath = intent.getStringExtra("IMAGE_PATH")

        // Tampilkan gambar
        currentPhotoPath?.let { path ->
            val imageFile = File(path)
            Glide.with(this)
                .load(imageFile)
                .into(previewImageView)
        }

        retakeImageButton.setOnClickListener {
            // Kembali ke CameraActivity untuk mengambil gambar ulang
            val intent = Intent(this, CameraActivity::class.java)
            startActivity(intent)
            finish()
        }

        uploadButton.setOnClickListener {
            processImage()
        }
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    private fun processImage() {
        currentPhotoPath?.let { path ->
            // Disable upload button and show progress indicator
            uploadButton.isEnabled = false
            progressIndicator.visibility = View.VISIBLE

            // Gunakan Coroutines untuk proses background
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    // Buat identifier unik untuk gambar
                    val images = generateTempImages()

                    // Kirim gambar ke API di main thread
                    withContext(Dispatchers.Main) {
                        sendImageToAPI(images)
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        progressIndicator.visibility = View.GONE
                        uploadButton.isEnabled = true
                        Toast.makeText(
                            this@ProcessActivity,
                            "Gagal memproses gambar: ${e.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        } ?: run {
            Toast.makeText(this, "Tidak ada gambar yang dipilih", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendImageToAPI(images: String) {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://eom-imagecapt-api-349085248843.asia-southeast2.run.app/")
            .addConverterFactory(GsonConverterFactory.create())
            .client(
                OkHttpClient.Builder()
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS)
                    .build()
            )
            .build()

        val apiService = retrofit.create(ImageCaptionApiService::class.java)

        // Create a MultipartBody.Part for the image file
        val file = File(currentPhotoPath!!)
        val requestBody = file.asRequestBody("image/*".toMediaTypeOrNull())
        val imagePart = MultipartBody.Part.createFormData("image", file.name, requestBody)

        apiService.generateCaption(imagePart).enqueue(object : Callback<ImageCaptionResponse> {
            override fun onResponse(
                call: Call<ImageCaptionResponse>,
                response: Response<ImageCaptionResponse>
            ) {
                progressIndicator.visibility = View.GONE
                uploadButton.isEnabled = true

                if (response.isSuccessful) {
                    val caption = response.body()?.caption ?: "Caption tidak tersedia"

                    // Simpan data ke Firestore dengan minimal informasi
                    val imageData = hashMapOf(
                        "images" to images,
                        "caption" to caption
                    )

                    firestore.collection("images")
                        .document(images)
                        .set(imageData)
                        .addOnSuccessListener {
                            val intent = Intent(this@ProcessActivity, DetailActivity::class.java).apply {
                                putExtra("IMAGE_PATH", currentPhotoPath)
                                putExtra("IMAGE_ID", images)
                            }
                            startActivity(intent)
                            finish()
                        }
                        .addOnFailureListener { e ->
                            Toast.makeText(
                                this@ProcessActivity,
                                "Gagal menyimpan data: ${e.message}",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                } else {
                    Toast.makeText(
                        this@ProcessActivity,
                        "Gagal mendapatkan caption: ${response.code()}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<ImageCaptionResponse>, t: Throwable) {
                progressIndicator.visibility = View.GONE
                uploadButton.isEnabled = true

                Toast.makeText(
                    this@ProcessActivity,
                    "Kesalahan jaringan: ${t.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    // API Service interface
    interface ImageCaptionApiService {
        @Multipart
        @POST("generate-caption")
        fun generateCaption(
            @Part image: MultipartBody.Part
        ): Call<ImageCaptionResponse>
    }

    // Response data class
    data class ImageCaptionResponse(val caption: String)

    private fun generateTempImages(): String {
        return "temp_${System.currentTimeMillis()}"
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}