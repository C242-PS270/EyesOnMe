package com.capstone.eyesonme.data

data class ImageCaption(
    val imageId: String = "",
    val url: String = "",
    val timestamp: String = "",
    val caption: String = ""
)
